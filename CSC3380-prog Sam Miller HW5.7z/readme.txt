Sam Miller
CSC 3380 4/14/17

to compile

javac TigerBook.java

to run

java TigerBook
